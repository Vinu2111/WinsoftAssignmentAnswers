
//Q4:Write a Java Program to find the duplicate characters in a string.

//Answers==>

/////Duplicates Character/////


package Answers;

import java.util.HashMap;

public class fourthQuestion {
    public static void main(String[] args) {
        String str = "programming";
        
        // Create a HashMap to store character counts
        HashMap<Character, Integer> charCounts = new HashMap<>();
        
        // Count the occurrences of each character
        for (char c : str.toCharArray()) {
            charCounts.put(c, charCounts.getOrDefault(c, 0) + 1);
        }
        
        // Print duplicate characters
        System.out.println("Duplicate characters:");
        for (char c : charCounts.keySet()) {
            if (charCounts.get(c) > 1) {
                System.out.println(c);
            }
        }
    }
}

