
//Write a Java Program to count the number of words in a string using HashMap.

//Answers==>

//////WordCount//////

package Answers;

import java.util.HashMap;

public class thirdQuestion {
    public static void main(String[] args) {
        String str = "This is a sample string with some words. Some words may appear more than once.";
        
        // Split the string into words
        String[] words = str.split("\\s+");
        
        // Create a HashMap to store word counts
        HashMap<String, Integer> wordCounts = new HashMap<>();
        
        // Count the occurrences of each word
        for (String word : words) {
            wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
        }
        
        // Print the word counts
        System.out.println("Word Counts:");
        for (String word : wordCounts.keySet()) {
            System.out.println(word + ": " + wordCounts.get(word));
        }
        
        // Total number of words
        int totalWords = words.length;
        System.out.println("Total number of words: " + totalWords);
    }
}

